<section>
	<div class="container mt-7">
		<div class="row">
			<div class="col-xl-12 col-lg-12 col-md-12">
				<div class="card">
					<div class="card-header pb-0 text-left bg-transparent">
						<h3 class="font-weight-bolder text-info text-gradient">Welcome back</h3>
						<p class="mb-0">Enter your email and password to sign in</p>
					</div>
					<div class="card-body">

					</div>
				</div>
			</div>
		</div>
	</div>
</section>